<header>
  <h1>Herzlichen Glückwunsch!</h1>
</header>
<section class="congratulations">
  <p class="name"><?= h($name) ?></p>
  <p>Sie können jetzt auch mit CakePHP entwickeln.</p>
</section>
<?= $this->Html->css('style.css') ?>